const express = require('express');
require('./config')
const product = require('./product')
const app = express()

app.use(express.json())

app.get('/search/:key',async(req,res)=>{
    let data = await product.find(
        {
           name:req.query.key
        }
    )
    res.send(data)  
});

app.listen(4500)