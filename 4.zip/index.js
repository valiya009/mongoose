const { isUtf8 } = require('buffer');
const fs = require('fs')
const path = require('path');
const dirpath = path.join(__dirname,'crud');
const filepath = `${dirpath}/apple.txt`
//create file
fs.writeFileSync(filepath,`file is created`);

//update file

fs.readFile(filepath,'utf-8',(err,item)=>{
    console.log(item);
    
})