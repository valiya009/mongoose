const mongoose = require('mongoose')
const productSchema = new mongoose.Schema(
{
        name : String ,
        id : Number,
        city : String
});

module.exports = mongoose.model('admin',productSchema)