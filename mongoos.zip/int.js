const  mongoose = require('mongoose')
const main = async ()=> {
    await mongoose.connect("mongodb://localhost:27017/school")
  

const StudentSchema = new mongoose.Schema({
    name:String,
    rno:Number,
    city:String
});

const StudentModel = mongoose.model('student',StudentSchema);
let data = new StudentModel({name:"chirag",rno:10,city:"ahm"});
let result = await data.save();
console.log(data);
}
main();
