const mongoose = require('mongoose');
const main = async () => {
 await
mongoose.connect("mongodb://127.0.0.1:27017/school");

 const StudentSchema = new
mongoose.Schema({
 name: String,
 rno : Number
 });
 const StudentModel =
mongoose.model('student',
StudentSchema);
 let data = new StudentModel({ name:
12,rno:"12",address:"bvn" });
 let result = await data.save();
 console.log(data)
}
main();