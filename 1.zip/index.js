const mongoose = require('mongoose');
mongoose.connect ("mongodb://localhost:27017/user");

const techSchema = new mongoose.Schema({
    name:String,
    id:Number,
    city : String
    
}); 

const saveIndb = async()=>
{
    const tech = mongoose.model('admin',techSchema)
    let data = new tech({
        name:'chandresh',
        id : 301,
        city :"bhavnagar"
    });
    const result = await data.save()
    console.log(data);
    
}


const updateIndb =async ()=>
{
    const tech = mongoose.model('admin',techSchema);
    let data = await tech.updateOne({name:'chandresh'},
       {
        $set:{name:'chandresh valiya',city:"gandhinagar"}
       }
    
       );
    console.log(data)
    }

const deleteIndb = async()=>
{
    const tech = mongoose.model('admin',techSchema);
    let data = await tech.deleteOne({name:'chandresh valiya',id:301});
    console.log(data);
    
}
deleteIndb();

