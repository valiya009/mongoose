const express = require('express')
const multer = require('multer');
const app = express()

const uplod = multer({
    storage: multer.diskStorage({
        destination:function (req,file,cb){
            cb(null,"upload")
        },
        filename:function(req,file,cb){
            cb(null,file.fieldname+"-"+Date.now()+".jpg")
        }
    })
}).single("upload_file")

app.post("/uplod",uplod,(req,res)=>{
    res.send("file uploded")
});

app.listen(3000);
